#ifndef __BATTLE_H__
#define __BATTLE_H__

class Player;
class Monster;

void battle_navigation(Player* player, Monster* monster);

#endif