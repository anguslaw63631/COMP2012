#ifndef __SORTED_SEQUENCE__
#define __SORTED_SEQUENCE__

#include <iostream>
#include <sstream>
#include <string>

template <typename T>
class SortedSequence{
  public:
    SortedSequence() : capacity_(0), size_(0), data_(nullptr) {}
    ~SortedSequence() { delete[] data_; }

    void add(const T &a) {  // Task 2 - To Do
      // memory allocation phase
      if (capacity_ == 0) {
        capacity_ = 1;
        data_ = new T[capacity_];
      }
      else if (capacity_ == size_) {
        capacity_ *= 2;
        T *temp = new T[capacity_];
        for (int i = 0; i < size_; i++) {
          temp[i] = data_[i];
        }
        delete[] data_;
        data_ = temp;
      }

      // element insertion phase
      int p = size_ - 1;
      while (p >= 0 && a < data_[p]) {
        data_[p + 1] = data_[p];
        p--;
      }
      data_[p + 1] = a;
      size_++;
    }

    std::string toString() const {
      std::stringstream ss;
      ss << "capacity: " << capacity_ << ", size: " << size_
        << ", data: " << std::endl;
      if (data_ == nullptr) {
        ss << "None";
      } else {
        for (int i = 0; i < size_; i++) {
          ss << data_[i] << " ";
        }
      }
      return ss.str();
    }

  private:
    int capacity_;
    int size_;
    T *data_;
};

template <typename T>
std::ostream& operator<<(std::ostream& os, const SortedSequence<T>& t) {
  os << t.toString();
  return os;
}

#endif
