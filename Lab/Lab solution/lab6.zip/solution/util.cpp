#include "util.h"

void print_report(){
    Technician::print_report();
    std::cout << "----------------------" << std::endl;
    std::cout << "REPORT FOR ELECTRONICS" << std::endl;
    std::cout << "----------------------" << std::endl;
    CPU::print_report();
    std::cout << '\n';
    MEM::print_report();
    std::cout << "----------------------" << std::endl;
    std::cout << "--- END OF REPORT ----" << std::endl;
    std::cout << "----------------------" << std::endl;
}