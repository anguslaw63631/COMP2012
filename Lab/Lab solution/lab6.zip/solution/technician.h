#ifndef __TECHNICIAN_H__
#define __TECHNICIAN_H__

#include "electronics.h"
#include <string>

class Computer;
class Diagnosis_Tool;

class Technician{
    private:
    std::string name;
    int num_order_finished;
    Diagnosis_Tool* diagnosis_tool;

    public:
    Technician() = delete;
    Technician(std::string, Diagnosis_Tool*);
    Technician(const Technician&) = delete;
    ~Technician();

    CPU* acquire_CPU(CPU_Model) const;
    MEM* acquire_MEM(MEM_Model) const;
    void repair(Computer*);
    
    static Technician* technician_list[];
    static int num_technician;
    static void print_report();
};

class Diagnosis_Tool{
    private:
    bool diagnose(Electronics* electronics){
        return electronics->healthy;
    }

    CPU_Model get_CPU_Model(CPU* cpu){
        return cpu->model;
    }

    MEM_Model get_MEM_Model(MEM* mem){
        return mem->model;
    }

    public:
    friend class Technician;
    Diagnosis_Tool() = default;
    Diagnosis_Tool(const Diagnosis_Tool&) = delete;
    ~Diagnosis_Tool() = default;
};

#endif