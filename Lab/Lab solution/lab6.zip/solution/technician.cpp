#include <iostream>
#include "technician.h"
#include "computer.h"
#include "electronics.h"

const int MAX_NUM_TECHNICIAN = 10;

int Technician::num_technician = 0;

Technician* Technician::technician_list[MAX_NUM_TECHNICIAN] {};

Technician::Technician(std::string name, Diagnosis_Tool* diagnosis_tool): name {name}, num_order_finished {0},
diagnosis_tool {diagnosis_tool} 
{
    technician_list[num_technician++] = this;
}

Technician::~Technician(){
    delete diagnosis_tool;
}

CPU* Technician::acquire_CPU(CPU_Model model) const {
    return new CPU(model);
}

MEM* Technician::acquire_MEM(MEM_Model model) const {
    return new MEM(model);
}

void Technician::repair(Computer* computer){
    bool cpu_healthy = diagnosis_tool->diagnose(computer->cpu);
    bool mem_healthy = diagnosis_tool->diagnose(computer->mem);
    if(!cpu_healthy){
        CPU* new_cpu = acquire_CPU(diagnosis_tool->get_CPU_Model(computer->cpu));
        delete computer->cpu;
        CPU::defect_count++;
        computer->cpu = new_cpu;
    }
    if(!mem_healthy){
        MEM* new_mem = acquire_MEM(diagnosis_tool->get_MEM_Model(computer->mem));
        delete computer->mem;
        MEM::defect_count++;
        computer->mem = new_mem;
    }
    this->num_order_finished++;
}

void Technician::print_report(){
    std::cout << "----------------------" << std::endl;
    std::cout << "REPORT FOR TECHNICIANS" << std::endl;
    std::cout << "----------------------" << std::endl;
    std::cout.width(20);
    std::cout << std::left << "NAME" << "ORDERS_COMPLETED" << std::endl;
    for(int i = 0; i < num_technician; ++i){
        std::cout.width(20);
        std::cout << std::left << technician_list[i]->name << technician_list[i]->num_order_finished << std::endl;
    }
}
