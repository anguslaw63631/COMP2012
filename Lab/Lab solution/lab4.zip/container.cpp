#include "container.h"
#include <iostream>

void Container::addObject(Object *object)   //Task 1&3
{
    if(_num_object < MAX_OBJECT_NUM)
    {
        if(object->getSize().x + object->getPosition().x <= getSize().x
    && object->getSize().y + object->getPosition().y <= getSize().y)
        {
            _objects[_num_object++] = object;
            object->setParent(this);
        }
        else
            cout << "The object " << object->getName() << " is too large and cannot be added to " << getName() << endl;
    }
}

void Container::display() const //Task 1
{
    cout << "\nContainer";
    displayBasic();
    cout << "\n\t\t";
    if(_num_object>0)
        cout << "#objects: " << _num_object << endl << endl;

    for (int i = 0; i < _num_object; i++)
        if (_objects[i] != nullptr)
            _objects[i]->display();

}

Container::Container() 
{
    for (int i = 0; i < MAX_OBJECT_NUM; i++)
        _objects[i] = nullptr;

    _num_object = 0;
}

Container::~Container()  //Task 1
{
    cout<<"\nDestructing Container "<< getName();
    for (int i = 0; i < _num_object; i++)
        if (_objects[i] != nullptr)
            delete _objects[i];
}